//! Exact FM-index search prototype. The index is reusable between query batches.
//! libsais constructs suffix arrays; candidate discovery and edit search are Rust.
use libsais::{SuffixArrayConstruction, ThreadCount};
use std::{collections::HashMap, io::{self, Read, Write}};

const MAGIC: &[u8;8] = b"OOFFFM01";

#[derive(Clone, Debug)]
struct RankBlock {
    masks: [u64;4],
    counts: [u32;4],
}

pub struct Index {
    // Full SA initially: direct locate, with its memory cost reported explicitly.
    sa: Vec<u32>,
    ranks: Vec<RankBlock>,
    cumulative: [u32;4],
}

fn encode(base: u8) -> u8 {
    match base { b'A'=>1,b'C'=>2,b'G'=>3,b'T'=>4,_=>5 }
}

impl Index {
    pub fn build(text: &[u8]) -> Self {
        assert!(text.len() < i32::MAX as usize - 1, "shard exceeds i32 suffix-array limit");
        let mut encoded: Vec<_> = text.iter().map(|&b|encode(b)).collect();
        encoded.push(0); // unique terminal sentinel
        let sa: Vec<i32> = SuffixArrayConstruction::for_text(&encoded)
            .in_owned_buffer().multi_threaded(ThreadCount::openmp_default())
            .run().expect("suffix array construction failed").into_vec();
        let mut totals=[0u32;4];
        for &b in &encoded { if (1..=4).contains(&b) {totals[b as usize-1]+=1;} }
        let mut cumulative=[1;4];
        for c in 1..4 {cumulative[c]=cumulative[c-1]+totals[c-1];}
        let mut ranks=Vec::with_capacity(encoded.len()/64+1);
        let mut counts=[0u32;4];
        for block_start in (0..encoded.len()).step_by(64) {
            let mut block=RankBlock {masks:[0;4],counts};
            for (bit,&suffix) in sa[block_start..(block_start+64).min(sa.len())].iter().enumerate() {
                let pos=suffix as usize;
                let c=encoded[if pos==0 {encoded.len()-1} else {pos-1}];
                if (1..=4).contains(&c) {block.masks[c as usize-1]|=1u64<<bit;counts[c as usize-1]+=1;}
            }
            ranks.push(block);
        }
        if encoded.len()%64==0 {ranks.push(RankBlock {masks:[0;4],counts});}
        Self {sa:sa.into_iter().map(|p|p as u32).collect(),ranks,cumulative}
    }

    pub fn len(&self) -> usize {self.sa.len()-1}
    pub fn is_empty(&self) -> bool {self.len()==0}
    pub fn bytes(&self) -> usize {self.sa.len()*4+self.ranks.len()*48+16}

    #[inline]
    fn rank(&self, c:usize, end:u32) -> u32 {
        let block=&self.ranks[end as usize/64];
        let bit=end%64;
        let mask=(1u64<<bit).wrapping_sub(1);
        block.counts[c]+(block.masks[c]&mask).count_ones()
    }

    #[inline]
    fn extend(&self, c:usize, lo:u32, hi:u32) -> (u32,u32) {
        (self.cumulative[c]+self.rank(c,lo),self.cumulative[c]+self.rank(c,hi))
    }

    /// Enumerate intervals, or stop at the first accepted witness. The callback
    /// can reject intended-gene hits without pruning other associations.
    /// A site may be visited at multiple costs; callers choose its minimum.
    pub fn search(&self, pattern:&[u8], k:usize, mut emit:impl FnMut(usize,usize,usize)->bool) -> bool {
        assert!(!pattern.is_empty() && k<pattern.len());
        assert!(pattern.iter().all(|b|matches!(b,b'A'|b'C'|b'G'|b'T')));
        let p:Vec<_>=pattern.iter().map(|&b|encode(b) as usize-1).collect();
        let mut memo=HashMap::new();
        self.visit(&p,p.len(),0,self.sa.len() as u32,k,0,k,&mut memo,&mut emit)
    }

    #[allow(clippy::too_many_arguments)]
    fn visit(&self,p:&[usize],remaining:usize,lo:u32,hi:u32,budget:usize,span:usize,k:usize,
        memo:&mut HashMap<(usize,u32,u32,usize),usize>,emit:&mut impl FnMut(usize,usize,usize)->bool) -> bool {
        if lo==hi {return false;}
        let key=(remaining,lo,hi,span);
        if memo.get(&key).is_some_and(|&prior|prior>=budget) {return false;}
        memo.insert(key,budget);
        if remaining==0 && span>0 {
            for &start in &self.sa[lo as usize..hi as usize] {
                if emit(start as usize,start as usize+span,k-budget) {return true;}
            }
        }
        if remaining>0 {
            let c=p[remaining-1];
            let (a,b)=self.extend(c,lo,hi);
            if self.visit(p,remaining-1,a,b,budget,span+1,k,memo,emit) {return true;}
        }
        if budget==0 {return false;}
        // I: consume one query base; no reference base.
        if remaining>0 && self.visit(p,remaining-1,lo,hi,budget-1,span,k,memo,emit) {return true;}
        for c in 0..4 {
            let (a,b)=self.extend(c,lo,hi);
            if a==b {continue;}
            // X: consume a different reference and query base.
            if remaining>0 && c!=p[remaining-1] && self.visit(p,remaining-1,a,b,budget-1,span+1,k,memo,emit) {return true;}
            // D: consume a reference base, including terminal RNA-extra bases.
            if self.visit(p,remaining,a,b,budget-1,span+1,k,memo,emit) {return true;}
        }
        false
    }

    pub fn write(&self,mut out:impl Write) -> io::Result<()> {
        out.write_all(MAGIC)?;
        out.write_all(&(self.sa.len() as u64).to_le_bytes())?;
        out.write_all(&(self.ranks.len() as u64).to_le_bytes())?;
        for x in self.cumulative {out.write_all(&x.to_le_bytes())?;}
        for &x in &self.sa {out.write_all(&x.to_le_bytes())?;}
        for block in &self.ranks {
            for x in block.masks {out.write_all(&x.to_le_bytes())?;}
            for x in block.counts {out.write_all(&x.to_le_bytes())?;}
        }
        Ok(())
    }

    pub fn read(mut input:impl Read) -> io::Result<Self> {
        fn u32read(r:&mut impl Read)->io::Result<u32>{let mut b=[0;4];r.read_exact(&mut b)?;Ok(u32::from_le_bytes(b))}
        fn u64read(r:&mut impl Read)->io::Result<u64>{let mut b=[0;8];r.read_exact(&mut b)?;Ok(u64::from_le_bytes(b))}
        let mut magic=[0;8];input.read_exact(&mut magic)?;
        if &magic!=MAGIC {return Err(io::Error::new(io::ErrorKind::InvalidData,"invalid index magic"));}
        let n=u64read(&mut input)? as usize;
        let blocks=u64read(&mut input)? as usize;
        if n==0 || n>=i32::MAX as usize || blocks!=n/64+1 {return Err(io::Error::new(io::ErrorKind::InvalidData,"invalid index dimensions"));}
        let mut cumulative=[0;4];for x in &mut cumulative {*x=u32read(&mut input)?;}
        let mut sa=Vec::with_capacity(n);
        for _ in 0..n {let pos=u32read(&mut input)?;if pos>=n as u32{return Err(io::Error::new(io::ErrorKind::InvalidData,"invalid suffix position"));}sa.push(pos);}
        let mut ranks=Vec::with_capacity(blocks);
        for _ in 0..blocks {
            let mut block=RankBlock {masks:[0;4],counts:[0;4]};
            for x in &mut block.masks {*x=u64read(&mut input)?;}
            for x in &mut block.counts {*x=u32read(&mut input)?;}
            ranks.push(block);
        }
        Ok(Self {sa,ranks,cumulative})
    }
}
