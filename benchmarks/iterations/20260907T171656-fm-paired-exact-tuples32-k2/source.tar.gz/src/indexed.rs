//! Annotated, reusable reference indexes for the normal CLI.
use crate::{Block, Record, Site, align_site, fm::Index, normalize};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    error::Error,
    fs::{self, File, OpenOptions},
    io::{BufRead, BufReader, BufWriter, Write},
    path::Path,
    time::UNIX_EPOCH,
};

type Result<T> = std::result::Result<T, Box<dyn Error>>;

#[derive(Serialize, Deserialize)]
pub struct FastaRecord {
    pub header: String,
    pub offset: usize,
    pub length: usize,
    pub line_bases: usize,
    pub line_bytes: usize,
}
#[derive(Serialize, Deserialize)]
pub struct ReferenceInfo {
    pub path: String,
    pub file_bytes: u64,
    pub modified_nanos: u128,
    pub sha256: String,
    pub unknown_bases: usize,
    pub records: Vec<FastaRecord>,
}

impl ReferenceInfo {
    pub fn create(reference: &Path, output: &Path) -> Result<Self> {
        let file = File::open(reference)?;
        let metadata = file.metadata()?;
        let modified_nanos = metadata.modified()?.duration_since(UNIX_EPOCH)?.as_nanos();
        let mut reader = BufReader::new(file);
        let mut hash = Sha256::new();
        let mut line = Vec::new();
        let mut position = 0;
        let mut records: Vec<FastaRecord> = Vec::new();
        let mut unknown_bases = 0;
        let mut short = false;
        loop {
            line.clear();
            let bytes = reader.read_until(b'\n', &mut line)?;
            if bytes == 0 {
                break;
            }
            hash.update(&line);
            let mut bases = bytes;
            if line.last() == Some(&b'\n') {
                bases -= 1;
            }
            if bases > 0 && line[bases - 1] == b'\r' {
                bases -= 1;
            }
            if line.first() == Some(&b'>') {
                if records.last().is_some_and(|r| r.length == 0) {
                    return Err("empty FASTA record".into());
                }
                records.push(FastaRecord {
                    header: String::from_utf8(line[1..bases].to_vec())?,
                    offset: position + bytes,
                    length: 0,
                    line_bases: 0,
                    line_bytes: 0,
                });
                short = false;
            } else {
                if bases == 0 || short {
                    return Err("invalid or inconsistently wrapped FASTA".into());
                }
                let record = records.last_mut().ok_or("FASTA sequence before header")?;
                if record.line_bases == 0 {
                    record.line_bases = bases;
                    record.line_bytes = bytes;
                } else if bases > record.line_bases
                    || (bases == record.line_bases && bytes != record.line_bytes && bytes != bases)
                {
                    return Err("inconsistent FASTA wrapping".into());
                }
                short = bases < record.line_bases;
                record.length += bases;
                unknown_bases += normalize(std::str::from_utf8(&line[..bases])?, false)?
                    .iter()
                    .filter(|&&b| b == b'N')
                    .count();
            }
            position += bytes;
        }
        if records.is_empty() || records.last().is_some_and(|r| r.length == 0) {
            return Err("empty FASTA reference".into());
        }
        let info = Self {
            path: fs::canonicalize(reference)?.display().to_string(),
            file_bytes: metadata.len(),
            modified_nanos,
            sha256: format!("{:x}", hash.finalize()),
            unknown_bases,
            records,
        };
        info.verify_file(reference)?;
        let mut writer = BufWriter::new(
            OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(output)?,
        );
        serde_json::to_writer(&mut writer, &info)?;
        writer.flush()?;
        Ok(info)
    }

    pub fn verify_file(&self, path: &Path) -> Result<()> {
        let metadata = fs::metadata(path)?;
        if fs::canonicalize(path)?.display().to_string() != self.path
            || metadata.len() != self.file_bytes
            || metadata.modified()?.duration_since(UNIX_EPOCH)?.as_nanos() != self.modified_nanos
        {
            return Err("reference differs from indexed source; rebuild the index".into());
        }
        Ok(())
    }
}

#[derive(Deserialize)]
struct IndexedRecord {
    header: String,
    start: usize,
    length: usize,
    global_id: usize,
}
#[derive(Deserialize)]
struct Shard {
    file: String,
    records: Vec<IndexedRecord>,
}
#[derive(Deserialize)]
struct Manifest {
    #[serde(default)]
    reverse_records: bool,
    reference_bases: usize,
    reference_records: usize,
    shards: Vec<Shard>,
    source_sha256: String,
}

#[derive(Deserialize)]
struct Annotation {
    id: String,
    genes: Vec<String>,
    #[serde(default)]
    transcripts: Vec<String>,
    contig: String,
    strand: String,
    blocks: Vec<Block>,
}

pub struct ReferenceIndex {
    manifest: Manifest,
    indexes: Vec<Index>,
    reverse_indexes: Option<Vec<Index>>,
    sequence: memmap2::Mmap,
    pub records: Vec<Record>,
    pub info: ReferenceInfo,
}

impl ReferenceIndex {
    /// # Safety
    /// Index and source files must remain immutable for this object's lifetime.
    pub unsafe fn open_immutable(
        directory: &Path,
        reference: &Path,
        annotations: &Path,
    ) -> Result<Self> {
        let manifest: Manifest =
            serde_json::from_reader(BufReader::new(File::open(directory.join("manifest.json"))?))?;
        if manifest.reverse_records {
            return Err("reversed experimental index requires paired-direction search".into());
        }
        let info: ReferenceInfo = serde_json::from_reader(BufReader::new(File::open(
            directory.join("reference-info.json"),
        )?))?;
        info.verify_file(reference)?;
        if manifest.source_sha256 != info.sha256
            || manifest.reference_records != info.records.len()
            || manifest.reference_bases != info.records.iter().map(|r| r.length).sum::<usize>()
        {
            return Err("index/reference provenance mismatch".into());
        }
        let mut records = Vec::with_capacity(manifest.reference_records);
        let mut ids = BTreeSet::new();
        for line in BufReader::new(File::open(annotations)?).lines() {
            let a: Annotation = serde_json::from_str(&line?)?;
            if !ids.insert(a.id.clone()) {
                return Err("duplicate annotation record ID".into());
            }
            let r = Record {
                id: a.id,
                sequence: String::new(),
                genes: a.genes,
                transcripts: a.transcripts,
                contig: a.contig,
                strand: a.strand,
                blocks: a.blocks,
            };
            let source = info
                .records
                .get(records.len())
                .ok_or("too many annotation records")?;
            let (id, genes) = source
                .header
                .split_once('|')
                .ok_or("FASTA header lacks gene associations")?;
            if r.id != id
                || r.genes.iter().map(String::as_str).collect::<BTreeSet<_>>()
                    != genes.split(',').collect()
            {
                return Err(
                    "annotation IDs/genes differ from indexed FASTA; order must match".into(),
                );
            }
            r.validate_metadata(source.length)?;
            records.push(r);
        }
        if records.len() != manifest.reference_records {
            return Err("missing annotation records".into());
        }
        for (i, r) in manifest.shards.iter().flat_map(|s| &s.records).enumerate() {
            if r.global_id != i
                || r.header != info.records[i].header
                || r.length != info.records[i].length
            {
                return Err("inconsistent index record metadata".into());
            }
        }
        let mut indexes = Vec::new();
        for s in &manifest.shards {
            let file = File::open(directory.join(&s.file))?;
            // SAFETY: index files are immutable artifacts; this API's documented
            // contract excludes concurrent writes/truncation by any process.
            indexes.push(unsafe { Index::map_immutable(&file) }?);
        }
        let source = File::open(reference)?;
        // SAFETY: the same immutability contract applies to the source reference.
        let sequence = unsafe { memmap2::MmapOptions::new().map(&source) }?;
        Ok(Self {
            manifest,
            indexes,
            reverse_indexes: None,
            sequence,
            records,
            info,
        })
    }

    pub fn reference_bases(&self) -> usize {
        self.manifest.reference_bases
    }

    fn interval(&self, rid: usize, start: usize, end: usize) -> Result<Vec<u8>> {
        let r = &self.info.records[rid];
        if start >= end || end > r.length {
            return Err("indexed hit outside reference record".into());
        }
        let bytes: Vec<_> = (start..end)
            .map(|p| self.sequence[r.offset + (p / r.line_bases) * r.line_bytes + p % r.line_bases])
            .collect();
        normalize(std::str::from_utf8(&bytes)?, false).map_err(Into::into)
    }

    /// Stream distinct sites one shard at a time. Report-mode memory is bounded
    /// by sites in a shard for one query; an explicit cap stops discovery.
    /// Attach an optional reversed-record index for exhaustive paired search.
    ///
    /// # Safety
    /// All index files must remain immutable for this object's lifetime.
    pub unsafe fn attach_reverse_immutable(&mut self, directory: &Path) -> Result<()> {
        let other: Manifest =
            serde_json::from_reader(BufReader::new(File::open(directory.join("manifest.json"))?))?;
        if !other.reverse_records
            || other.source_sha256 != self.manifest.source_sha256
            || other.shards.len() != self.manifest.shards.len()
        {
            return Err("reverse index provenance mismatch".into());
        }
        let mut indexes = Vec::new();
        for (a, b) in other.shards.iter().zip(&self.manifest.shards) {
            if a.records.len() != b.records.len() {
                return Err("reverse shard mismatch".into());
            }
            for (x, y) in a.records.iter().zip(&b.records) {
                if (&x.header, x.start, x.length, x.global_id)
                    != (&y.header, y.start, y.length, y.global_id)
                {
                    return Err("reverse record mismatch".into());
                }
            }
            let file = File::open(directory.join(&a.file))?;
            // SAFETY: caller guarantees immutable reverse-index artifacts.
            indexes.push(unsafe { Index::map_immutable(&file) }?);
        }
        self.reverse_indexes = Some(indexes);
        Ok(())
    }

    pub fn search(
        &self,
        pattern: &[u8],
        intended: &[String],
        k: usize,
        screen: bool,
        cap: Option<usize>,
        mut emit: impl FnMut(&Record, Site) -> Result<()>,
    ) -> Result<(usize, bool)> {
        let mut count = 0;
        for (shard_no, (shard, index)) in self.manifest.shards.iter().zip(&self.indexes).enumerate()
        {
            let mut sites = BTreeMap::new();
            let mut collect = |a: usize, b: usize, d: usize, reverse: bool| {
                let p = shard.records.partition_point(|r| r.start <= a);
                if p == 0 {
                    return false;
                }
                let r = &shard.records[p - 1];
                assert!(b <= r.start + r.length, "index crossed a record boundary");
                if self.records[r.global_id]
                    .genes
                    .iter()
                    .all(|g| intended.contains(g))
                {
                    return false;
                }
                let (a, b) = if reverse {
                    (
                        r.start + r.length - (b - r.start),
                        r.start + r.length - (a - r.start),
                    )
                } else {
                    (a, b)
                };
                let old = sites
                    .entry((r.global_id, a - r.start, b - r.start))
                    .or_insert(d);
                *old = (*old).min(d);
                screen || cap.is_some_and(|n| count + sites.len() >= n)
            };
            let stopped = if let Some(reverse) = &self.reverse_indexes {
                let first =
                    index.search_limited(pattern, k, true, |a, b, d| collect(a, b, d, false));
                if first {
                    true
                } else {
                    let reversed: Vec<_> = pattern.iter().rev().copied().collect();
                    reverse[shard_no]
                        .search_limited(&reversed, k, true, |a, b, d| collect(a, b, d, true))
                }
            } else {
                index.search(pattern, k, |a, b, d| collect(a, b, d, false))
            };
            for ((rid, a, b), _) in sites {
                let target = self.interval(rid, a, b)?;
                let site = align_site(pattern, &target, a);
                if target.contains(&b'N') || site.edit_distance > k {
                    return Err("indexed witness failed independent interval verification".into());
                }
                emit(&self.records[rid], site)?;
                count += 1;
            }
            if stopped {
                return Ok((count, !screen));
            }
        }
        Ok((count, false))
    }
}
